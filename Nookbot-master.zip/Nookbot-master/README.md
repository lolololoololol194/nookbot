# Nookbot
Discord.js bot for the Animal Crossing: New Horizons Discord server,
[discord.gg/acnh](https://discord.gg/acnh)!